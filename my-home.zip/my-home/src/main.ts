import { initHACoding } from 'ha-coding';

import('./devices/devices.js');

initHACoding().then(() => {
    import('./automation/index.js');
});
