import './bathroom-light-automation.js';
