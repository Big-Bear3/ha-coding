import { createDevice } from 'ha-coding';
import { MiLight } from '../devices-def/mi-light.js';
import { MiTrio } from '../devices-def/mi-trio.js';

/** 卫生间设备 */
export const bathroom = {
    lamp: createDevice(MiLight, { light: 'your entity id' }),
    occupySensor: createDevice(MiTrio, {
        allArea: 'your entity id',
        illumination: 'your entity id',
        area1: 'your entity id',
        area2: 'your entity id'
    })
};
