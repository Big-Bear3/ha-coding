export default {
    IP_ADDRESS_PORT: '',
    HA_USER_NAME: '',
    HA_PASSWORD: ''
};
